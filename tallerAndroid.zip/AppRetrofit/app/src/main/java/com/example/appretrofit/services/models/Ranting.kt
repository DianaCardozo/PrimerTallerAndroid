package com.example.appretrofit.services.models

data class Ranting(
    var rate: Double,
    var count: Int
)
