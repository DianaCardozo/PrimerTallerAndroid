package com.example.appretrofit.services.models


data class LoginRequest(
    val email: String,
    val password: String
)

data class UserResponse(
    val success: Boolean,
    val message: String
)

// data/models/Product.kt
data class Product(
    val id: Int,
    val name: String,
    val category: String,
    val price: Double
)